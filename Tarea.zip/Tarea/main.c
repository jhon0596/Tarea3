#include <stdio.h>
#include <time.h>
#include <math.h>
int main() {

    int arr1[]={1233, 1033, 1044  , 4804, 25, 2951, 314, 3680, 2523, 4507, 1545, 712, 4147, 2743, 3618, 2681, 3036, 3460, 3515, 1943, 1858, 1504, 201, 3400, 128};
    int arr2[] ={4648, 3817, 2648, 1892, 4159, 593, 1962, 707, 2770, 102, 2288, 1149, 4357, 881, 3226, 627, 1797, 975, 3517, 1201, 4942, 2769, 4126, 666, 1719, 2772, 2390, 2988, 946, 4247, 901, 4980, 2495, 283, 993, 4280, 2752, 3433, 2513, 4325, 659, 635, 413, 1844, 461, 3258, 1621, 4098, 3968, 801};
    int arr3[]={906, 922, 2511, 1007, 3103, 356, 353, 826, 2898, 977, 4993, 1456, 4185, 1795, 3526, 4509, 2628, 3427, 4165, 4047, 2370, 1106, 3000, 54, 213, 3735, 2061, 3716, 505, 1859, 4945, 4873, 3939, 4708, 2372, 1764, 3795, 899, 2668, 2901, 820, 3840, 1365, 866, 2485, 1834, 4933, 1297, 608, 735, 2980, 2345, 3955, 3445, 1942, 4097, 2165, 3752, 2876, 2847, 3525, 908, 1779, 1860, 2217, 4826, 4072, 4666, 1976, 3765, 3996, 2855, 2365, 657, 1931};
    int arr4[] = {3848, 606, 3940, 3550, 4027, 3517, 1555, 1670, 3639, 1107, 1888, 2690, 3182, 2378, 4699, 4392, 3519, 764, 2460, 3834, 2000, 2284, 4799, 465, 4661, 482, 1580, 2286, 4909, 445, 1515, 4650, 4550, 3670, 1255, 13, 1068, 3764, 1022, 28, 883, 1836, 2065, 3679, 4488, 1356, 4773, 2049, 4840, 4419, 228, 2232, 1383, 1835, 4408, 760, 978, 3501, 4178, 1890, 2295, 2612, 1646, 432, 3353, 4931, 4875, 3491, 3539, 2584, 4782, 122, 3880, 808, 3943, 3614, 317, 3224, 1323, 1969, 2838, 3018, 4907, 1541, 4867, 1176, 4336, 86, 3494, 1785, 1971, 3267, 2552, 934, 199, 1268, 695, 2501, 1734, 4850};
    int n1 = sizeof(arr1)/ sizeof(arr1[0]);
    int n2 = sizeof(arr2)/ sizeof(arr2[0]);
    int n3 = sizeof(arr3)/ sizeof(arr3[0]);
    int n4 = sizeof(arr4)/ sizeof(arr4[0]);
    clock_t tInicio, tFinal;
    double secs;
    tInicio = clock();
    insertionSort(arr1,n1);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del insertion sort con 25 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    bubbleSort(arr1,n1);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del bubble sort con 25 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    selectionSort(arr1,n1);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del selection sort con 25 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
/////////////////////////////////////////////////////////////////////////////
    tInicio = clock();
    insertionSort(arr2,n2);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del insertion sort con 50 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    bubbleSort(arr2,n2);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del bubble sort con 50 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    selectionSort(arr2,n2);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del selection sort con 50 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    ///////////////////////////////////////////////////////////////
    tInicio = clock();
    insertionSort(arr3,n3);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del insertion sort con 75 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    bubbleSort(arr3,n3);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del bubble sort con 75 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    selectionSort(arr3,n3);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del selection sort con 75 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    ////////////////////////////////////////////////////////////////////////
    tInicio = clock();
    insertionSort(arr4,n4);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del insertion sort con 100 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    bubbleSort(arr4,n4);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del bubble sort con 100 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    tInicio = clock();
    selectionSort(arr4,n4);
    tFinal = clock();
    secs = (double)(tFinal-tInicio)/CLOCKS_PER_SEC;
    printf("Tiempo de ejecucion del selection sort con 100 elementos: ");
    printf("%.16g milisegundos\n",secs*1000.0);
    return 0;
}
void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void insertionSort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;

        /* Move elements of arr[0..i-1], that are
          greater than key, to one position ahead
          of their current position */
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

// A function to implement bubble sort
void bubbleSort(int arr[], int n)
{
    int i, j;
    for (i = 0; i < n-1; i++)

        // Last i elements are already in place
        for (j = 0; j < n-i-1; j++)
            if (arr[j] > arr[j+1])
                swap(&arr[j], &arr[j+1]);
}
void selectionSort(int arr[], int n)
{
    int i, j, min_idx;

    // One by one move boundary of unsorted subarray
    for (i = 0; i < n-1; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j < n; j++)
            if (arr[j] < arr[min_idx])
                min_idx = j;

        // Swap the found minimum element with the first element
        swap(&arr[min_idx], &arr[i]);
    }
}